##About
Sungka (SOONG-KAH) is a [game-type] application that follows the same rules as that of the classic and widely known and played Sungka (Philippine mancala game). 

Sungka was developed as a project in CMSC 125.


##How to run
(1) Enter ./install.sh on terminal

(2) Boot ics-os

(3) Go to apps folder

(4) Enter sungka.exe


##Authors
Perico Dan Dionisio

Coleen Bobilles
